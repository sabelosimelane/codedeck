import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 43000,
    proxy: {
      '/api': 'http://localhost:43001',
      '/ws': {
        target: 'ws://localhost:43001',
        ws: true,
      },
    },
  },
});
